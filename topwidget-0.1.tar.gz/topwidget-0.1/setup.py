from setuptools import setup

setup(name='topwidget',
      version='0.1',
      description='useful top widget for kivy',
      url='https://github.com/sroskom/test_projects',
      author='STROS',
      author_email='sterlingroskom@gmail.com',
      license='Copyright Protected',
      packages=['topwidget'],
      zip_safe=False)
